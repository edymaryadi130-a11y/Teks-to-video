package com.veo.studio

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxWidth()) { VeoApp() }
            }
        }
    }
}

private const val MODEL_ID = "gemini-omni-1.1-flash"

private val RESOLUTIONS = listOf("720p", "1080p")

private val ASPECTS = listOf(
    "Landscape 16:9" to "16:9",
    "Potret 9:16" to "9:16",
)

@Composable
fun VeoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("veo", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var tab by remember { mutableStateOf(0) }
    var resIdx by remember { mutableStateOf(0) }
    var aspectIdx by remember { mutableStateOf(0) }
    var prompt by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var resultFile by remember { mutableStateOf<File?>(null) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) imageUri = uri
    }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Veo Studio", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = apiKey,
            onValueChange = {
                apiKey = it
                prefs.edit().putString("api_key", it.trim()).apply()
            },
            label = { Text("Gemini API key") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Text to Video") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Image to Video") })
        }

        Text("Format video", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ASPECTS.forEachIndexed { i, (label, _) ->
                FilterChip(selected = aspectIdx == i, onClick = { aspectIdx = i }, label = { Text(label) })
            }
        }

        Text("Resolusi", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RESOLUTIONS.forEachIndexed { i, label ->
                FilterChip(selected = resIdx == i, onClick = { resIdx = i }, label = { Text(label) })
            }
        }

        if (tab == 1) {
            OutlinedButton(onClick = { pickImage.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (imageUri == null) "Pilih gambar awal" else "Gambar dipilih (ketuk untuk ganti)")
            }
        }

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text(if (tab == 0) "Prompt" else "Prompt gerakan") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = negative,
            onValueChange = { negative = it },
            label = { Text("Negative prompt (opsional)") },
            modifier = Modifier.fillMaxWidth(),
        )

        val startGeneration: () -> Unit = {
                when {
                    apiKey.isBlank() -> toast(context, "Isi API key dulu.")
                    prompt.isBlank() -> toast(context, "Prompt tidak boleh kosong.")
                    tab == 1 && imageUri == null -> toast(context, "Pilih gambar dulu.")
                    else -> {
                        busy = true
                        resultFile = null
                        status = "Memulai..."
                        scope.launch {
                            try {
                                val image = if (tab == 1) {
                                    val uri = imageUri!!
                                    val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                                    bytes to (context.contentResolver.getType(uri) ?: "image/png")
                                } else null
                                val out = File(context.cacheDir, "veo_${System.currentTimeMillis()}.mp4")
                                VeoClient(apiKey.trim()).generate(
                                    model = MODEL_ID,
                                    resolution = RESOLUTIONS[resIdx],
                                    prompt = prompt.trim(),
                                    aspectRatio = ASPECTS[aspectIdx].second,
                                    negativePrompt = negative.trim(),
                                    image = image,
                                    outFile = out,
                                    onStatus = { status = it },
                                )
                                resultFile = out
                                status = "Selesai."
                            } catch (e: Exception) {
                                status = "Gagal: ${e.message}"
                            } finally {
                                busy = false
                            }
                        }
                    }
                }
        }

        Button(
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            onClick = startGeneration,
        ) { Text(if (busy) "Memproses..." else "Generate") }

        if (busy) CircularProgressIndicator()
        if (status.isNotBlank()) Text(status)

        resultFile?.let { file ->
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (aspectIdx == 0) 16f / 9f else 9f / 16f),
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setMediaController(MediaController(ctx).also { it.setAnchorView(this) })
                        setVideoURI(Uri.fromFile(file))
                        setOnPreparedListener { it.isLooping = true; start() }
                    }
                },
                update = { view ->
                    view.setVideoURI(Uri.fromFile(file))
                    view.start()
                },
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = { saveToDownloads(context, file) },
            ) { Text("Download video") }
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = { saveToGallery(context, file) },
            ) { Text("Simpan ke galeri") }
            OutlinedButton(
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = startGeneration,
            ) { Text("Generate ulang") }
        }
    }
}

private fun toast(context: Context, msg: String) =
    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

private fun saveToDownloads(context: Context, file: File) {
    val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, "veo_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
        put(MediaStore.Downloads.RELATIVE_PATH, "Download/VeoStudio")
    }
    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
    if (uri == null) {
        toast(context, "Gagal mendownload.")
        return
    }
    context.contentResolver.openOutputStream(uri)?.use { out ->
        file.inputStream().use { it.copyTo(out) }
    }
    toast(context, "Tersimpan di folder Download/VeoStudio")
}

private fun saveToGallery(context: Context, file: File) {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "veo_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VeoStudio")
    }
    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
    if (uri == null) {
        toast(context, "Gagal menyimpan.")
        return
    }
    context.contentResolver.openOutputStream(uri)?.use { out ->
        file.inputStream().use { it.copyTo(out) }
    }
    toast(context, "Tersimpan di Movies/VeoStudio")
}
