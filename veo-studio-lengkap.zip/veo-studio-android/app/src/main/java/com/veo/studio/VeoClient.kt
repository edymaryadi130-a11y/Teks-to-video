package com.veo.studio

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Klien video Gemini API memakai Interactions API (model gemini-omni-1.1-flash).
 * Veo 3.1 di Gemini API sudah ditutup 22 Oktober 2026.
 */
class VeoClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(2, TimeUnit.MINUTES)
        .build()

    private val base = "https://generativelanguage.googleapis.com/v1beta"

    /**
     * image: pasangan (bytes gambar, mime type) untuk Image to Video, null untuk Text to Video.
     */
    suspend fun generate(
        model: String,
        prompt: String,
        aspectRatio: String,
        resolution: String,
        negativePrompt: String,
        image: Pair<ByteArray, String>?,
        outFile: File,
        onStatus: (String) -> Unit,
    ) = coroutineScope {
        // Interactions API tidak punya kolom negative prompt, jadi disisipkan ke teks prompt.
        val fullPrompt =
            if (negativePrompt.isBlank()) prompt else "$prompt\n\nHindari: $negativePrompt"

        val input: Any = if (image == null) {
            fullPrompt
        } else {
            JSONArray()
                .put(
                    JSONObject()
                        .put("type", "image")
                        .put("data", Base64.encodeToString(image.first, Base64.NO_WRAP))
                        .put("mime_type", image.second)
                )
                .put(JSONObject().put("type", "text").put("text", fullPrompt))
        }

        val body = JSONObject()
            .put("model", model)
            .put("input", input)
            .put(
                "response_format",
                JSONObject()
                    .put("type", "video")
                    .put("aspect_ratio", aspectRatio)
                    .put("resolution", resolution)
            )
        if (image != null) {
            body.put(
                "generation_config",
                JSONObject().put("video_config", JSONObject().put("task", "image_to_video"))
            )
        }

        val ticker = launch {
            var s = 0
            while (true) {
                onStatus("Sedang diproses... $s detik (bisa beberapa menit)")
                delay(1000)
                s++
            }
        }

        try {
            withContext(Dispatchers.IO) {
                val req = Request.Builder()
                    .url("$base/interactions")
                    .header("x-goog-api-key", apiKey)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val text = http.newCall(req).execute().use { resp ->
                    val t = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) throw VeoException(errorMessage(resp.code, t))
                    t
                }

                val json = JSONObject(text)
                val video = findVideo(json)
                    ?: throw VeoException(
                        "Tidak ada video di respons (mungkin terblokir filter keamanan). " +
                            "Coba ubah prompt. Detail: ${text.take(300)}"
                    )

                val data = video.optString("data")
                if (data.isNotBlank()) {
                    outFile.outputStream().use { it.write(Base64.decode(data, Base64.DEFAULT)) }
                } else {
                    // Cadangan: video dikirim lewat URI (Files API).
                    val uri = video.optString("uri")
                    val id = uri.substringAfter("files/").substringBefore(":").substringBefore("?")
                    if (id.isBlank()) throw VeoException("Respons video tidak berisi data maupun URI.")
                    val dl = Request.Builder()
                        .url("$base/files/$id:download?alt=media")
                        .header("x-goog-api-key", apiKey)
                        .build()
                    http.newCall(dl).execute().use { r ->
                        if (!r.isSuccessful) throw VeoException(errorMessage(r.code, r.body?.string().orEmpty()))
                        outFile.outputStream().use { out -> r.body!!.byteStream().copyTo(out) }
                    }
                }
            }
        } finally {
            ticker.cancel()
        }
        onStatus("Selesai.")
    }

    /** Daftar model yang tersedia untuk API key ini (nama tanpa awalan "models/"). */
    suspend fun listModels(): List<String> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$base/models?pageSize=200")
            .header("x-goog-api-key", apiKey)
            .build()
        http.newCall(req).execute().use { resp ->
            val t = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw VeoException(errorMessage(resp.code, t))
            val arr = JSONObject(t).optJSONArray("models") ?: JSONArray()
            (0 until arr.length())
                .map { arr.getJSONObject(it).optString("name").removePrefix("models/") }
                .filter { it.isNotBlank() }
                .sortedWith(compareBy({ !(it.contains("omni") || it.contains("veo")) }, { it }))
        }
    }

    /** Cari item bertipe "video" di mana pun posisinya dalam JSON respons. */
    private fun findVideo(node: Any?): JSONObject? {
        when (node) {
            is JSONObject -> {
                if (node.optString("type") == "video" && (node.has("data") || node.has("uri"))) return node
                for (k in node.keys()) findVideo(node.opt(k))?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) findVideo(node.opt(i))?.let { return it }
        }
        return null
    }

    private fun errorMessage(code: Int, body: String): String {
        val msg = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        if (code == 429) {
            return "Error 429: kuota habis, atau API key masih Free Tier (generate video tidak tersedia di Free Tier). " +
                "Aktifkan billing di Google AI Studio (ai.dev/rate-limit), lalu coba lagi.\n\n" +
                "Detail: ${msg ?: body.take(200)}"
        }
        return "Error $code: ${msg ?: body.take(300)}"
    }
}

class VeoException(message: String) : Exception(message)
