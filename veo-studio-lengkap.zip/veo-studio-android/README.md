# Veo Studio (Android)

Aplikasi Android (Kotlin + Jetpack Compose) untuk membuat video dengan Veo 3 lewat Gemini API.
Fitur: Text to Video, Image to Video, format Landscape 16:9 atau Potret 9:16, simpan hasil ke galeri.

## Build APK lewat GitHub (tanpa Android Studio)

1. Buat repo baru di GitHub, lalu upload semua isi folder ini:
   ```
   git init
   git add .
   git commit -m "Veo Studio Android"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```
2. Buka tab **Actions** di repo, tunggu workflow **Build APK** selesai (sekitar 5-10 menit).
3. Buka run yang berhasil, bagian **Artifacts**, download **VeoStudio-debug-apk**, ekstrak ZIP-nya.
4. Kirim `app-debug.apk` ke HP dan install (izinkan "install dari sumber tidak dikenal").

## Build lokal (opsional)

Buka folder ini di Android Studio, lalu Run. Atau dengan Gradle 8.7+ dan JDK 17: `gradle assembleDebug`.

## Memakai aplikasi

1. Ambil API key di https://aistudio.google.com/apikey
2. Buka aplikasi, tempel API key di kolom paling atas lalu ketuk **Simpan** (disimpan di penyimpanan privat aplikasi). Pilih model lewat **Pilih model**, atau ketuk **Muat daftar dari API** untuk melihat model yang tersedia di key-mu, atau ketik Model ID manual. Hanya model yang mendukung pembuatan video yang akan berhasil.
3. Pilih tab, format video, dan model, tulis prompt, lalu ketuk **Generate**.
4. Proses butuh beberapa menit. Setelah selesai, video diputar dan bisa disimpan ke galeri.

## Catatan

- API key tidak ditanam di kode, jadi aman di-push ke GitHub. Jangan membagikan APK yang sudah berisi key kamu.
- Generate video berbayar per video. Cek harga terbaru di dokumentasi Gemini API.
- Veo 3.1 di Gemini API ditutup 22 Oktober 2026. Aplikasi ini memakai penggantinya, Gemini Omni Flash (`gemini-omni-1.1-flash`) lewat Interactions API. Jika nama model berubah, edit `MODEL_ID` di `MainActivity.kt`.
- Negative prompt disisipkan ke teks prompt karena API baru tidak punya kolom khusus untuk itu.
