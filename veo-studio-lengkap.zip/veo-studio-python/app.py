import base64
import mimetypes
import os
import time

import gradio as gr
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise SystemExit("GEMINI_API_KEY belum diisi. Salin .env.example menjadi .env lalu isi kuncinya.")

# Veo 3.1 di Gemini API ditutup 22 Oktober 2026; penggantinya Gemini Omni Flash.
MODEL_ID = "gemini-omni-1.1-flash"
URL = "https://generativelanguage.googleapis.com/v1beta/interactions"

ASPECTS = {"Landscape (16:9)": "16:9", "Potret (9:16)": "9:16"}
RESOLUTIONS = ["720p", "1080p"]

OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def _find_video(node):
    if isinstance(node, dict):
        if node.get("type") == "video" and ("data" in node or "uri" in node):
            return node
        for v in node.values():
            found = _find_video(v)
            if found:
                return found
    elif isinstance(node, list):
        for v in node:
            found = _find_video(v)
            if found:
                return found
    return None


def _run(prompt, aspect_label, resolution, negative_prompt, image_path=None):
    if not prompt or not prompt.strip():
        raise gr.Error("Prompt tidak boleh kosong.")

    text = prompt.strip()
    if negative_prompt and negative_prompt.strip():
        text += f"\n\nHindari: {negative_prompt.strip()}"

    body = {
        "model": MODEL_ID,
        "response_format": {
            "type": "video",
            "aspect_ratio": ASPECTS[aspect_label],
            "resolution": resolution,
        },
    }

    if image_path:
        mime = mimetypes.guess_type(image_path)[0] or "image/png"
        with open(image_path, "rb") as f:
            data = base64.b64encode(f.read()).decode()
        body["input"] = [
            {"type": "image", "data": data, "mime_type": mime},
            {"type": "text", "text": text},
        ]
        body["generation_config"] = {"video_config": {"task": "image_to_video"}}
    else:
        body["input"] = text

    try:
        resp = requests.post(URL, json=body, headers={"x-goog-api-key": API_KEY}, timeout=600)
    except requests.RequestException as e:
        raise gr.Error(f"Gagal terhubung ke API: {e}")

    if not resp.ok:
        try:
            msg = resp.json()["error"]["message"]
        except Exception:
            msg = resp.text[:300]
        if resp.status_code == 429:
            raise gr.Error(
                "Error 429: kuota habis, atau API key masih Free Tier (generate video tidak tersedia di Free Tier). "
                f"Aktifkan billing di Google AI Studio (ai.dev/rate-limit), lalu coba lagi. Detail: {msg}"
            )
        raise gr.Error(f"Error {resp.status_code}: {msg}")

    video = _find_video(resp.json())
    if not video or not video.get("data"):
        raise gr.Error("Tidak ada video di respons (mungkin terblokir filter keamanan). Coba ubah prompt.")

    out_path = os.path.join(OUTPUT_DIR, f"video_{int(time.time())}.mp4")
    with open(out_path, "wb") as f:
        f.write(base64.b64decode(video["data"]))
    return out_path


def text_to_video(prompt, aspect_label, resolution, negative_prompt):
    return _run(prompt, aspect_label, resolution, negative_prompt)


def image_to_video(image_path, prompt, aspect_label, resolution, negative_prompt):
    if not image_path:
        raise gr.Error("Upload gambar dulu.")
    return _run(prompt, aspect_label, resolution, negative_prompt, image_path)


with gr.Blocks(title="Video Generator (Gemini Omni)") as app:
    gr.Markdown("# Video Generator (Gemini Omni Flash)\nText to Video dan Image to Video, landscape atau potret.")

    with gr.Row():
        aspect_dd = gr.Dropdown(list(ASPECTS), value=list(ASPECTS)[0], label="Format video")
        res_dd = gr.Dropdown(RESOLUTIONS, value=RESOLUTIONS[0], label="Resolusi")

    neg = gr.Textbox(label="Negative prompt (opsional)", placeholder="blur, teks, watermark")

    with gr.Tab("Text to Video"):
        p1 = gr.Textbox(label="Prompt", lines=4, placeholder="Seorang wanita berjalan di pantai saat senja, sinematik...")
        b1 = gr.Button("Generate", variant="primary")
        v1 = gr.Video(label="Hasil", show_download_button=True)
        b1.click(text_to_video, [p1, aspect_dd, res_dd, neg], v1)

    with gr.Tab("Image to Video"):
        img = gr.Image(type="filepath", label="Gambar awal")
        p2 = gr.Textbox(label="Prompt gerakan", lines=3, placeholder="Kamera zoom perlahan, rambutnya tertiup angin...")
        b2 = gr.Button("Generate", variant="primary")
        v2 = gr.Video(label="Hasil", show_download_button=True)
        b2.click(image_to_video, [img, p2, aspect_dd, res_dd, neg], v2)

if __name__ == "__main__":
    app.queue().launch()
