# Video Generator (Gemini Omni)

Aplikasi Text to Video dan Image to Video memakai Gemini Omni Flash (Gemini API; pengganti Veo yang ditutup 22 Okt 2026), dengan pilihan format landscape (16:9) atau potret (9:16).

## Cara pakai

1. Ambil API key di https://aistudio.google.com/apikey
2. Install dependensi:
   ```
   pip install -r requirements.txt
   ```
3. Salin `.env.example` menjadi `.env`, lalu isi `GEMINI_API_KEY`.
4. Jalankan:
   ```
   python app.py
   ```
5. Buka alamat yang muncul di terminal (biasanya http://127.0.0.1:7860).

## Push ke GitHub

```
git init
git add .
git commit -m "Veo 3 video generator"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```

File `.env` sudah masuk `.gitignore`, jadi kunci API tidak ikut ter-upload.

## Catatan

- Generate video butuh beberapa menit dan berbayar per video (cek harga terbaru di dokumentasi Gemini API).
- Jika nama model berubah, edit `MODEL_ID` di `app.py`.
